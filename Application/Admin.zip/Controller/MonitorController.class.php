<?php
namespace Admin\Controller;
use Think\Controller;

class MonitorController extends CommonController {
    
    public function lists() {
        $this->display();
    }


}